import React, { useState, useEffect } from 'react';
import HospitalCard from './HospitalCard';
import './HospitalList.css';

const HospitalList = () => {
  const [city, setCity] = useState('delhi');
  const [hospitals, setHospitals] = useState([]);

  useEffect(() => {
    fetchHospitals(city);
  }, [city]);

  const fetchHospitals = async (selectedCity) => {
    try {
      const response = await fetch(`http://localhost:4000/api/v1/hospitals?city=${selectedCity}`);
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      let data = await response.json();
      data = data['result'];
      if (Array.isArray(data)) {
        setHospitals(data);
      } else {
        console.error('Expected an array but received:', data);
        setHospitals([]);
      }
    } catch (error) {
      console.error('Error fetching hospitals:', error);
      setHospitals([]);
    }
  };

  const handleCityChange = (event) => {
    setCity(event.target.value);
  };

  const handleDelete = async (id) => {
    try {
      const response = await fetch(`http://localhost:4000/api/v1/hospitals/delete?id=${id}`, {
        method: 'DELETE',
      });
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      setHospitals(hospitals.filter(hospital => hospital._id !== id));
    } catch (error) {
      console.error('Error deleting hospital:', error);
    }
  };

  const handleEdit = async (updatedHospital) => {
    try {
      const response = await fetch(`http://localhost:4000/api/v1/hospitals/update?id=${updatedHospital._id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updatedHospital),
      });
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      // Update the hospital in the state
      setHospitals(hospitals.map(hospital => hospital._id === updatedHospital._id ? updatedHospital : hospital));
    } catch (error) {
      console.error('Error updating hospital:', error);
    }
  };

  return (
    <div className="hospital-list">
      <h2>Find Hospitals by City</h2>
      <select value={city} onChange={handleCityChange}>
        <option value="delhi">Delhi</option>
        <option value="jalandhar">Jalandhar</option>
        <option value="amritsar">Amritsar</option>
        <option value="noida">Noida</option>
      </select>
      <div className="hospital-cards">
        {hospitals.map(hospital => (
          <HospitalCard key={hospital._id} hospital={hospital} onDelete={handleDelete} onEdit={handleEdit} />
        ))}
      </div>
    </div>
  );
};

export default HospitalList;
