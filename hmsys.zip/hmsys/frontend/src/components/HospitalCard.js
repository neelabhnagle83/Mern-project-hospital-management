import React, { useState } from 'react';
import EditHospitalModal from './EditHospitalModal'; // Import the modal component
import './HospitalCard.css';

const HospitalCard = ({ hospital, onDelete, onEdit }) => {
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleEditClick = () => {
    setIsModalOpen(true);
  };

  return (
    <div className="hospital-card">
      <img src={hospital.image} alt={hospital.name} className="hospital-image" />
      <div className="hospital-details">
        <h3>{hospital.name}</h3>
        <p><strong>City:</strong> {hospital.city}</p>
        <p><strong>Specialities:</strong> {hospital.speciality.join(', ')}</p>
        <p><strong>Rating:</strong> {hospital.rating}</p>
        <p><strong>Description:</strong> {hospital.description}</p>
        <p><strong>Number of Doctors:</strong> {hospital.numberOfDoctors}</p>
        <p><strong>Number of Departments:</strong> {hospital.numberOfDepartments}</p>
        <button className="edit-hospital-btn" onClick={handleEditClick}>ADD detials</button>
        <button className="delete-hospital-btn" onClick={() => onDelete(hospital._id)}>Delete</button>
      </div>
      {isModalOpen && <EditHospitalModal hospital={hospital} onClose={() => setIsModalOpen(false)} onSave={onEdit} />}
    </div>
  );
};

export default HospitalCard;
