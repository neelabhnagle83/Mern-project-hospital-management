import React, { useState } from 'react';
import './Modal.css';

const Modal = ({ show, handleClose }) => {
  const [formData, setFormData] = useState({
    name: '',
    city: '',
    imageUrl: '',
    specialities: [],
    rating: 0
  });

  const specialitiesOptions = ['Cardiology', 'Neurology', 'Pediatrics', 'Orthopedics'];

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  const handleMultiSelectChange = (e) => {
    const { options } = e.target;
    const selectedOptions = Array.from(options).filter(option => option.selected).map(option => option.value);
    setFormData({ ...formData, specialities: selectedOptions });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const response = await fetch('http://localhost:4000/api/v1/hospitals/create', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          name_: formData.name,
          city: formData.city,
          image: formData.imageUrl,
          speciality: formData.specialities,
          rating: parseFloat(formData.rating)
        })
      });
      if (response.ok) {
        const data = await response.json();
        console.log('Hospital created successfully:', data);
        handleClose();
      } else {
        console.error('Error creating hospital:', response.statusText);
      }
    } catch (error) {
      console.error('Error creating hospital:', error);
    }
  };

  if (!show) {
    return null;
  }

  return (
    <div className="modal-overlay">
      <div className="modal">
        <h2>Create Hospital</h2>
        <form onSubmit={handleSubmit}>
          <label>
            Hospital Name:
            <input type="text" name="name" value={formData.name} onChange={handleChange} required />
          </label>
          <label>
            City:
            <input type="text" name="city" value={formData.city} onChange={handleChange} required />
          </label>
          <label>
            Image URL:
            <input type="url" name="imageUrl" value={formData.imageUrl} onChange={handleChange} required />
          </label>
          <label>
            Specialities:
            <select multiple={true} value={formData.specialities} onChange={handleMultiSelectChange} required>
              {specialitiesOptions.map(option => (
                <option key={option} value={option}>{option}</option>
              ))}
            </select>
          </label>
          <label>
            Rating:
            <input type="number" name="rating" value={formData.rating} onChange={handleChange} min="0" max="5" step="0.1" required />
          </label>
          <div className="modal-buttons">
            <button type="button" onClick={handleClose}>Cancel</button>
            <button type="submit">Submit</button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default Modal;
