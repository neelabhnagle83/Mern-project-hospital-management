import React, { useState } from 'react';
import './EditHospitalModal.css';

const EditHospitalModal = ({ hospital, onClose, onSave }) => {
  const [description, setDescription] = useState(hospital.description);
  const [numberOfDoctors, setNumberOfDoctors] = useState(hospital.numberOfDoctors);
  const [numberOfDepartments, setNumberOfDepartments] = useState(hospital.numberOfDepartments);
  const [image, setImage] = useState(hospital.image); // Assuming there's a single image

  const handleSubmit = async () => {
    const updatedHospital = {
      ...hospital,
      description,
      numberOfDoctors,
      numberOfDepartments,
      image,
    };

    // Call the onSave prop function to update the hospital
    onSave(updatedHospital);

    // Close the modal
    onClose();
  };

  return (
    <div className="edit-hospital-modal">
      <h2>Edit Hospital</h2>
      <label>
        Description:
        <input type="text" value={description} onChange={(e) => setDescription(e.target.value)} />
      </label>
      <label>
        Number of Doctors:
        <input type="number" value={numberOfDoctors} onChange={(e) => setNumberOfDoctors(e.target.value)} />
      </label>
      <label>
        Number of Departments:
        <input type="number" value={numberOfDepartments} onChange={(e) => setNumberOfDepartments(e.target.value)} />
      </label>
      <label>
        Image URL:
        <input type="text" value={image} onChange={(e) => setImage(e.target.value)} />
      </label>
      <div className="modal-actions">
        <button onClick={handleSubmit}>Submit</button>
        <button onClick={onClose}>Cancel</button>
      </div>
    </div>
  );
};

export default EditHospitalModal;
