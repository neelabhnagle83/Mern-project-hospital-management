import React, { useState } from 'react';
import './Navbar.css';
import Modal from './Modal';

const Navbar = () => {
  const [showModal, setShowModal] = useState(false);

  const handleOpenModal = () => {
    setShowModal(true);
  };

  const handleCloseModal = () => {
    setShowModal(false);
  };

  return (
    <div>
      <nav className="navbar">
        <div className="navbar-title">Hospital Management System</div>
        <ul className="navbar-links">
          <li><a href="#home">Home</a></li>
          <li><a href="#services">Services</a></li>
          <li><a href="#location">Location</a></li>
          <li><a href="#appointment">Book Appointment</a></li>
        </ul>
        <button className="create-hospital-btn" onClick={handleOpenModal}>Create Hospital</button>
      </nav>
      <Modal show={showModal} handleClose={handleCloseModal} />
    </div>
  );
};

export default Navbar;
