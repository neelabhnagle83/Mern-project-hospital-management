const mongoose=require('mongoose');

const OrganisationSchema=new mongoose.Schema({
    name:{type:String},
    city:{type:String},
    image:{type:String},
    speciality:[{type: String}],
    rating:{type:Number},
    description:{type:String},
    images:[{type: String}],
    numberOfDocters:{type:Number},
    numberOfDepartment:{type:Number}
});

module.exports=mongoose.model("OrganisationDetails",OrganisationSchema);