const express = require('express');
const cors = require('cors');
const model=require('./db/schema');

require('./db/connectDB');

const app = express();
app.use(cors());
app.use(express.json());

app.post('/api/v1/hospitals/create',async (req, res) => {
    try {
        let name_, city, image, speciality, rating
        ({name_, city, image, speciality, rating} = req.body)
        description =''
        images =[]
        numberOfDocters=0
        numberOfDepartment = 0
        await model.create({name:name_, city, image, speciality, rating, description, images, numberOfDocters, numberOfDepartment});
        return res.status(200).send({ok:1})
    } catch (err) {
        res.status(500).send({ok:0,err});
    }
});

app.get('/api/v1/hospitals',async (req, res) => {
    try {
        let city = req.query.city
        // console.log("city:",city)
        let result = await model.find({city});
        // console.log("result",result)
        return res.status(200).send({ok:1, result})
    } catch (err) {
        consle.log("errrrrrrrrrrrrr",err)
        res.status(500).send({ok:0,err});
    }
});

app.delete('/api/v1/hospitals/delete',async (req, res) => {
    try {
        let _id = req.query.id
        await model.deleteOne({_id});
        return res.status(200).send({ok:1})
    } catch (err) {
        res.status(500).send({ok:0,err});
    }
});

app.put('/api/v1/hospitals/update',async (req, res) => {
    try {
        let _id = req.query.id
        let name_, city, image, speciality, rating, description, images, numberOfDocters, numberOfDepartment
        ({name_, city, image, speciality, rating, description, images, numberOfDocters, numberOfDepartment} = req.body)
        await model.updateOne({_id},{$set: {name:name_, city, image, speciality, rating, description, images, numberOfDocters, numberOfDepartment}});
        return res.status(200).send({ok:1})
    } catch (err) {
        res.status(500).send({ok:0,err});
    }
});

app.post('/api/v1/hospitals/details',async (req, res) => {
    try {
        let _id = req.query.id
        let description, images, numberOfDocters, numberOfDepartment
        ({description, images, numberOfDocters, numberOfDepartment} =  req.body)
        await model.updateOne({_id},{$set: {description, images, numberOfDocters, numberOfDepartment}});
        return res.status(200).send({ok:1})
    } catch (err) {
        res.status(500).send({ok:0,err});
    }
});

app.listen(4000);